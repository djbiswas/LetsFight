<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ViewVote extends Model
{
     protected $table = 'view_votes';
}
