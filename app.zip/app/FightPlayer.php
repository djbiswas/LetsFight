<?php

namespace App;


use Illuminate\Database\Eloquent\Relations\Pivot;

class FightPlayer extends Pivot
{
    //protected $table = 'fight_player';
}
